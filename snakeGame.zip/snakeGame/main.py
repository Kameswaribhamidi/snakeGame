from turtle import Screen
from snake import Snake
from food import Food
from scoreBoard import Scoreboard
import time


scr = Screen()
scr.setup(width = 600, height = 600)
scr.bgcolor("black")
scr.title("Snake Game")
scr.tracer(0)  # Animation is set to 'OFF'

snake = Snake()  # Creating snake object
food = Food()  # Food object
score = Scoreboard()  # score board object


# Creating keyboard controls
scr.listen()
scr.onkey(snake.up, "Up")
scr.onkey(snake.down, "Down")
scr.onkey(snake.left, "Left")
scr.onkey(snake.right, "Right")


game_on = True
while game_on:
    scr.update()
    time.sleep(0.1)
    snake.auto_forward()
    
    # Detect collision with food
    if snake.head.distance(food) < 15:
        food.refresh_food()
        snake.extend_snake()
        score.increment()
        
    # Detect collision with wall
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        score.reset_score()
        snake.reset_snake()
    
    # Detect collision with tail
    for seg in snake.turtles:
        if seg == snake.head:
            pass
        elif snake.head.distance(seg) < 10:
           score.reset()
           snake.reset_snake()
        
        
        
        
scr.exitonclick()