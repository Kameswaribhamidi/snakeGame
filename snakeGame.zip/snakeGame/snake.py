from turtle import Turtle

# Constant values
POSITIONS = [(0, 0), (-20, 0), (-40, 0)]
MOVING_DIST = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0

# The Snake class
class Snake:
    def __init__(self):
        self.turtles = []
        self.body_of_snake()
        self.head = self.turtles[0]
        
    def body_of_snake(self):
        """ Creates snake body int the form of squares (3 squares) """
        for pos in POSITIONS:
            self.add_body(pos)
            
    def auto_forward(self):
        """ Makes the snake move forward automatically """
        for t_num in range(len(self.turtles) - 1, 0, -1):
            new_x = self.turtles[t_num - 1].xcor()
            new_y = self.turtles[t_num - 1].ycor()
            self.turtles[t_num].goto(new_x, new_y)
        self.head.forward(MOVING_DIST)

    def add_body(self, pos):
        turtle = Turtle(shape = "square")
        turtle.color("white")
        turtle.penup()
        turtle.goto(pos)
        self.turtles.append(turtle)
    
    def extend_snake(self):
        """ Add a new segment to snake """
        self.add_body(self.turtles[-1].position())
    
    def reset_snake(self):
        for seg in self.turtles:
            seg.goto(1000, 1000)
        self.turtles.clear()
        self.body_of_snake()
        self.head == self.turtles[0]
      
    def up(self): 
        if self.head.heading() != DOWN:
            self.head.setheading(90)
        
    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(180)
        
    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(270)
        
    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(0)