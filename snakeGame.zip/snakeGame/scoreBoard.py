from turtle import Turtle

ALLIGNMENT = 'center'
FONT = ('Times New Roman', 24,'normal')


class Scoreboard(Turtle):  # Inheriting turtle into score board
    def __init__(self):
        super().__init__()
        self.cur_score = 0
        self.file_path = "hScore.txt"
        with open(self.file_path) as data:
            self.highscore = int(data.read())
        self.color("white")
        self.penup()
        self.goto(0, 260)
        self.hideturtle()
        self.update_score()

    def update_score(self):
        self.clear()
        self.write(f"Score: {self.cur_score} High score: {self.highscore}", align = ALLIGNMENT, font = FONT)
    
    def reset_score(self):
        if self.cur_score > self.highscore:
            self.highscore = self.cur_score
            with open(self.file_path, 'w') as data:
                data.write(f"{self.highscore}")
        self.cur_score = 0
        self.update_score()
        
    def increment(self):
        self.cur_score += 1
        self.update_score()
    